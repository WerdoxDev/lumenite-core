<template>
    <div class="w-full h-14 absolute bottom-0 left-0">
        <h1 class="text-center text-xl">تمام حقوق متعلق به متین تات میباشد</h1>
    </div>
</template>

<script lang="ts">
import { defineComponent } from "vue";

export default defineComponent({
    name: "Footer",
});
</script>
